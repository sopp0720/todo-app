<template>
    <!-- html 기본적으로 컴포넌트 하나당 HTML tag는 루트레벨에서 하나만 있어야 한다. child 형태로 추가되어야 함 -->
    <header>
        <h1>TODO it!</h1>
    </header>
</template>

<script>
export default {
    // js script
    // 바깥여백, 폰트의 여백에 따라 같이 달라지는 여백  : rem */
}
</script>

<style scoped>
    h1 {
        color: #2f3b52;
        font-weight: 900;        
        margin: 2.5rem 0 1.5rem;
    }
</style>
