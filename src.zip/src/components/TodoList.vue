<template>
    <div>
        <!-- ul>li*3 단축키 -->
        <ul>
            <li></li>
            <li></li>
            <li></li>
        </ul>


    </div>
</template>

<script>
export default {
    data: function() {
        return {
            todoItems: []
        }
    },
    created: function() {
        if(localStorage.length > 0) {
            for (var i =0 ; localStorage.length ; i ++) {
                if(localStorage.key(i) !== 'loglevel:webpack-dev-server'){
                    this.todoItems.push(localStorage.key(i));
                }                
                //console.log(localStorage.key(i));
            }
        }
    }
}
</script>

<style>

</style>
